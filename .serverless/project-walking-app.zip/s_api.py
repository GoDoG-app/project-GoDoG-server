import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='jjni58',
    application_name='project-walking-app',
    app_uid='JtJz0Q5fkY2f0GXd7L',
    org_uid='6707b151-06a4-462a-aa77-717081234d30',
    deployment_uid='aba7160a-c75a-4825-b6fb-1ae8a75cdad9',
    service_name='project-walking-app',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'project-walking-app-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
